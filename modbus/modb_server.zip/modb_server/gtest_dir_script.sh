#!/bin/bash
export GTEST_DIR=/mnt/e/googletest/googletest
echo Current gtestdir is: $GTEST_DIR 
export GTEST_DIR=/mnt/c/Users/lauri_svpuigm/OneDrive/Projektit/google_test_enviroment/googletest/googletest
