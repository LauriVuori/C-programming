int my_strlen(char *s);

int my_strcmp (char *s, char *d);

void my_strcpy(char *d,char *s);

int str2upper(char *s);
int str2lower(char *s);

int str_strip_numbers( char *s);

char * my_strdupl(char *s);