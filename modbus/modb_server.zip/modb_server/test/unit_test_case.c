#include <gtest/gtest.h>
#include <stdio.h>
#include "../include/include.h"

// Assertions Reference
// https://google.github.io/googletest/reference/assertions.html

TEST(init_ringbuffer, first_test) {
    printf("terve");
}